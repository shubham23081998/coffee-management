import React, { useEffect, useState } from 'react'
import CoffeeTable from '../components/CoffeeTable';
import { getAllConffee, transferCoffee, updateAsset } from '../restService';
import { Button, Form, Modal } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
    const [user, setUser] = useState({})
    const [myCoffees, setMyCoffees] = useState([]);
    const [newOwner, setNewOwner] = useState("");
    const [currentCoffee, setCurrentCoffee] = useState({});
    const [openUpdateModal, setOpenUpdateModal] = useState(false);
    const navigate = useNavigate();
    useEffect(() => {
        const ud = JSON.parse(localStorage.getItem("user"));
        if (ud.role == "farmer") {
            setNewOwner("Processor");
        } else if (ud.role == "processor") {
            setNewOwner("Distributor");
        } else if (ud.role == "distributor") {
            setNewOwner("Retailer");
        }
        setUser(ud);
    }, [])

    useEffect(() => {
        getAllConffee().then((resp) => {
            let data = resp.data.data
            // if (user.role == RE) {
            //     data = resp.filter(c => c.producedBy == "farmer")
            // } else if (user.role == "processor") {
            //     data = resp.filter(c => c.processedBy == "processor")
            // }
            data = data.filter(c => c.traceability.org == user.role)
            console.log(data);
            setMyCoffees(data);
        })
    }, [user])

    const onPressTransfer = (batchId) => {
        const data = {
            batchId, currentowner: user.role, newowner: newOwner.toLowerCase()
        };
        console.log(data);
        transferCoffee(data).then((resp) => {
            console.log(resp);
            const data = myCoffees.filter(c => c.batchId != batchId);
            setMyCoffees(data)
        })
    }

    const onPressUpdate = (batchId) => {
        const c = myCoffees.filter(c => c.batchId == batchId);
        setCurrentCoffee(c[0]);
        setOpenUpdateModal(!openUpdateModal);
    }

    const makeUpdateApiCAll = (batchId, status, price) => {
        const data = {
            batchId, status, price
        }

        updateAsset(data).then(resp => {
            console.log("Update - ", resp);
            console.log(data);
            setOpenUpdateModal(!openUpdateModal);
        })
    }

    return (
        <div className="container">
            <div className="row mt-5">
                <div className="col">
                    {user.role == "farmer" && <button className="btn btn-primary mt-5" onClick={() => {
                        navigate("/farmer/createCoffee");
                    }}>
                        Create Coffee
                    </button>}
                </div>
                <div className="col">
                    <h1 className="text-danger">Welcome </h1>
                    <h2 className="text-success">{user.name}</h2>
                </div>
            </div>
            <div className="row mt-4">
                {openUpdateModal && <UpdateModal coffee={currentCoffee} onClose={onPressUpdate} onPress={makeUpdateApiCAll} />}
                <CoffeeTable user={user} coffees={myCoffees} newOwner={newOwner} onPressTransfer={onPressTransfer} onPressUpdate={onPressUpdate} />
            </div>
        </div>
    )
}

const UpdateModal = ({ coffee, onClose, onPress }) => {
    const [batchId, setBatchId] = useState("");
    const [status, setStatus] = useState("");
    const [price, setPrice] = useState("");

    useEffect(() => {
        console.log(coffee);
        setBatchId(coffee.batchId);
        setStatus(coffee.status);
        setPrice(coffee.price);
        console.log(status);
    }, [])

    const onChangeStatus = (event) => {
        setStatus(event.target.value);
    }

    return <div style={{
        display: 'block',
        width: 700,
        padding: 30, position: "absolute", zIndex: 99, backgroundColor: "white", left: "20%"
    }}
        className='shadow mx-auto'
    >        <Modal.Dialog>
            <Modal.Header closeButton onClick={onClose}>
                <Modal.Title>
                    Update Coffee
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form className="shadow p-4 bg-white rounded" onSubmit={(event) => {
                    event.preventDefault();
                    onPress(batchId, status, price)
                }}>
                    <Form.Group className="mb-2" controlId="password">
                        <Form.Label>BatchId</Form.Label>
                        <Form.Control
                            type="text"
                            value={batchId}
                            placeholder="Password"
                            disabled
                        />
                    </Form.Group>
                    <Form.Group className="mb-2" controlId="password">
                        <Form.Label>Status</Form.Label>
                        <Form.Select onChange={onChangeStatus} value={status}>
                            <option value={""} disabled selected>Select</option>
                            <option value={"PLANTED"}>Planted</option>
                            <option value="CROPPED">Cropped</option>
                            <option value="PROCESSED">Processed</option>
                        </Form.Select>
                    </Form.Group>
                    <Form.Group className="mb-2" controlId="password">
                        <Form.Label>Price</Form.Label>
                        <Form.Control
                            type="number"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                        />
                    </Form.Group>
                    <Button className="w-25" variant="primary" type="submit">
                        Update
                    </Button>
                </Form>
            </Modal.Body>
        </Modal.Dialog>
    </div>
}
export default Dashboard;