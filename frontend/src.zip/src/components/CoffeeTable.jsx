import React from 'react'
import PropTypes from 'prop-types'

const CoffeeTable = ({ coffees, newOwner, onPressTransfer, onPressUpdate, user }) => {
    return (
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Batch Id</th>
                    <th scope="col">Variety</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Origin</th>
                    <th scope="col">Status</th>
                    <th scope="col">Price</th>
                    <th scope="col">Current Owner</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                {
                    coffees.map((coffee, index) => <tr>
                        <th scope="row">{coffee.batchId}</th>
                        <td>{coffee.variety}</td>
                        <td>{coffee.quantity}</td>
                        <td>{coffee.origin}</td>
                        <td>{coffee.status}</td>
                        <td>{coffee.price}</td>
                        <td>{coffee.traceability.org}</td>
                        <td>
                            <div>
                                {user.role != "farmer" && <button className='btn btn-primary m-2 my-0' onClick={() => onPressUpdate(coffee.batchId)}>Update</button>}
                                <button className='btn btn-success my-0' onClick={() => onPressTransfer(coffee.batchId)}>Transfer {`To ${newOwner}`}</button>
                            </div>
                        </td>
                    </tr>)
                }

            </tbody>
        </table>)
}

CoffeeTable.propTypes = {}

export default CoffeeTable